using UnityEngine;
using UnityEngine.SceneManagement;

public class SahneYoneticisi : MonoBehaviour
{
    public void OyunSahnesineGit()
    {
        SceneManager.LoadScene("OyunSahnesi");
    }

    public void AyarlarSahnesineGit()
    {
        SceneManager.LoadScene("AyarlarSahnesi");
    }

    public void GirisSahnesineDon()
    {
        SceneManager.LoadScene("GirisSahnesi");
    }
}